import { loadImage, Canvas } from "skia-canvas";
import { j as json } from "../../../../chunks/index.js";
async function getSkin(username) {
  if (!valid(username))
    return Promise.reject(`${username} is an invalid username`);
  const UUID = await getUUID(username);
  const response = await fetch(`https://sessionserver.mojang.com/session/minecraft/profile/${UUID}`);
  if (!response.ok)
    return Promise.reject(`Response returned statuscode ${response.status}`);
  const json2 = await response.json();
  const r = JSON.parse(atob(json2.properties[0].value));
  return r.textures.SKIN.url;
}
async function getUUID(username) {
  if (!valid(username))
    return Promise.reject(`${username} is an invalid username`);
  const response = await fetch(`https://api.mojang.com/users/profiles/minecraft/${username}`);
  if (!response.ok)
    return Promise.reject(`${username} does not exist`);
  const json2 = await response.json();
  return json2.id;
}
function valid(username) {
  return username.match(/^[a-z0-9_]{1,16}$/i);
}
const prefix = process.env.NODE_ENV === "development" ? "http://localhost:5173" : "https://pfp.arcticbd.net";
async function generatePfp(username, ctx, type) {
  try {
    if (!username) {
      drawFailed(ctx);
      return;
    }
    const skinURL = await getSkin(username);
    const skinImage = await loadImage(skinURL);
    const shading = await loadImage(`${prefix}/20x20pshading.png`);
    const backdrop = await loadImage(`${prefix}/backdropshading.png`);
    ctx.drawImage(backdrop, 0, 0, 20, 20);
    if (skinImage.height === 32) {
      ctx.drawImage(skinImage, 8, 9, 7, 7, 8, 4, 7, 7);
      ctx.drawImage(skinImage, 5, 9, 3, 7, 5, 4, 3, 7);
      ctx.drawImage(skinImage, 44, 20, 3, 7, 12, 13, 3, 7);
      ctx.drawImage(skinImage, 21, 20, 6, 1, 7, 11, 6, 1);
      ctx.drawImage(skinImage, 20, 21, 8, 8, 6, 12, 8, 8);
      ctx.drawImage(skinImage, 44, 20, 3, 7, 5, 13, 3, 7);
      ctx.drawImage(skinImage, 40, 9, 7, 7, 8, 4, 7, 7);
      ctx.drawImage(skinImage, 33, 9, 3, 7, 5, 4, 3, 7);
    } else {
      ctx.drawImage(skinImage, 8, 9, 7, 7, 8, 4, 7, 7);
      ctx.drawImage(skinImage, 5, 9, 3, 7, 5, 4, 3, 7);
      ctx.drawImage(skinImage, 36, 52, 3, 7, 12, 13, 3, 7);
      ctx.drawImage(skinImage, 21, 20, 6, 1, 7, 11, 6, 1);
      ctx.drawImage(skinImage, 20, 21, 8, 8, 6, 12, 8, 8);
      ctx.drawImage(skinImage, 44, 20, 3, 7, 5, 13, 3, 7);
      ctx.drawImage(skinImage, 40, 9, 7, 7, 8, 4, 7, 7);
      ctx.drawImage(skinImage, 33, 9, 3, 7, 5, 4, 3, 7);
      ctx.drawImage(skinImage, 52, 52, 3, 7, 12, 13, 3, 7);
      ctx.drawImage(skinImage, 52, 36, 3, 7, 5, 13, 3, 7);
      ctx.drawImage(skinImage, 20, 37, 8, 8, 6, 12, 8, 8);
      ctx.drawImage(skinImage, 21, 36, 6, 1, 7, 11, 6, 1);
    }
    ctx.drawImage(shading, 0, 0, 20, 20);
    if (type == "ban") {
      const banned = await loadImage(`${prefix}/banned_big.png`);
      ctx.globalAlpha = 0.4;
      ctx.drawImage(banned, 0, 0, 18.5, 18.5);
    } else if (type == "warn") {
      const warning = await loadImage(`${prefix}/warn.png`);
      ctx.globalAlpha = 0.4;
      ctx.drawImage(warning, 0, 0, 18.5, 18.5);
    } else if (type == "jail") {
      const jail = await loadImage(`${prefix}/jail.png`);
      ctx.globalAlpha = 0.9;
      ctx.drawImage(jail, 0, 0, 18.5, 20);
    } else if (type == "mute") {
      const mute = await loadImage(`${prefix}/mute.png`);
      ctx.globalAlpha = 0.8;
      ctx.drawImage(mute, 0, 0, 18.5, 20);
    } else if (type == "kick") {
      const kick = await loadImage(`${prefix}/kick.png`);
      ctx.globalAlpha = 0.6;
      ctx.drawImage(kick, 0, 0, 18.5, 20);
    }
  } catch (e) {
    await drawFailed(ctx);
  }
}
async function drawFailed(ctx) {
  const failed = await loadImage(`${prefix}/PFP/notFound.png`);
  const shading = await loadImage(`${prefix}/20x20pshading.png`);
  const backdrop = await loadImage(`${prefix}/backdropshading.png`);
  ctx.drawImage(backdrop, 0, 0, 20, 20);
  ctx.resetTransform();
  ctx.drawImage(failed, 0, 0, 300, 300);
  ctx.scale(16, 16);
  ctx.drawImage(shading, 0, 0, 20, 20);
}
function changeGradient(ctx, colours = ["#00cdac", "#7338fc"]) {
  colours ??= ["#57cffa", "#387dfc"];
  const gradient = ctx.createLinearGradient(0, 18.75, 0, 0);
  let interval = 1;
  const decrement = 1 / (colours.length - 1);
  colours.forEach((colour) => {
    gradient.addColorStop(interval, colour);
    interval -= decrement;
  });
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 18.75, 18.75);
}
async function GET({ setHeaders, url }) {
  const username = url.searchParams.get("username");
  if (!username) {
    return json({
      status: 400,
      headers: {
        "Content-Type": "application/json"
      },
      body: {
        error: "Missing username"
      }
    });
  }
  try {
    const searchParams = url.searchParams;
    const type = searchParams.get("type");
    const gradient = searchParams.get("gradient");
    const colours = gradient ? gradient.split("-").filter((v) => v !== "").map((colour) => `#${colour}`) : null;
    const canvas = new Canvas(300, 300);
    const ctx = canvas.getContext("2d");
    ctx.scale(16, 16);
    ctx.imageSmoothingEnabled = false;
    changeGradient(ctx, colours);
    await generatePfp(username, ctx, type);
    const dataURL = await canvas.png;
    console.log(dataURL);
    return new Response(dataURL);
  } catch (e) {
    console.log(e);
    return json({
      status: 400,
      headers: {
        "Content-Type": "application/json"
      },
      body: {
        message: "oops"
      }
    });
  }
}
export {
  GET
};
