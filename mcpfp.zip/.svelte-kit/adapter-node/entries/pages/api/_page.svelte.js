import { c as create_ssr_component } from "../../../chunks/ssr.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div id="wrapper" data-svelte-h="svelte-1vswedp"><span><h1>The API is currently being worked on!</h1></span> <br> <span><a href="/">return to homepage ↩</a></span></div>`;
});
export {
  Page as default
};
