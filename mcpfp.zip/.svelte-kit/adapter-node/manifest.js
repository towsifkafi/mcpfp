export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["20x20pshading.png","backdropshading.png","banned.png","banned_big.png","darkMode.png","favicon.png","fonts/Minecraft(old).ttf","fonts/Minecraft.eot","fonts/Minecraft.svg","fonts/Minecraft.ttf","fonts/Minecraft.woff","fonts/Minecraft.woff2","jail.png","kick.png","lightMode.png","mute.png","PFP/elii_bx.png","PFP/E_Like_Cats__.png","PFP/fundy.png","PFP/I_Like_Cats__.png","PFP/notFound.png","PFP/purpled.png","PFP/SmarteOwl.png","PFP/tommyinnit.png","PFP/wilbursoot.png","warn.png"]),
	mimeTypes: {".png":"image/png",".ttf":"font/ttf",".eot":"application/vnd.ms-fontobject",".svg":"image/svg+xml",".woff":"font/woff",".woff2":"font/woff2"},
	_: {
		client: {"start":"_app/immutable/entry/start.74ded6f1.js","app":"_app/immutable/entry/app.0e9c339a.js","imports":["_app/immutable/entry/start.74ded6f1.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/singletons.97b3af82.js","_app/immutable/entry/app.0e9c339a.js","_app/immutable/chunks/scheduler.e108d1fd.js","_app/immutable/chunks/index.0719bd3d.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/api",
				pattern: /^\/api\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/api/pfp",
				pattern: /^\/api\/pfp\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/pfp/_server.js'))
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();